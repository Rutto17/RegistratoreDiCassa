﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cassa
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int[] schei = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0 };
        int[] scheiCliente = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0 };
        int[] scheiCarrello = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0 };
        int moltiplicatore = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (VerificoCheSianoGiustiSoldi(comboBox1, comboBox2) == true)
            {
                DammiMotiplicatore(comboBox2);
                if (comboBox1.Text == "1 centesimo")
                {
                    schei[0] = schei[0] + 1 * moltiplicatore;
                }
                if (comboBox1.Text == "2 centesimi")
                {
                    schei[1] = schei[1] + 2 * moltiplicatore;
                }
                if (comboBox1.Text == "5 centesimi")
                {
                    schei[2] = schei[2] + 5 * moltiplicatore;
                }
                if (comboBox1.Text == "10 centesimi")
                {
                    schei[3] = schei[3] + 10 * moltiplicatore;
                }
                if (comboBox1.Text == "20 centesimi")
                {
                    schei[4] = schei[4] + 20 * moltiplicatore;
                }
                if (comboBox1.Text == "50 centesimi")
                {
                    schei[5] = schei[5] + 50 * moltiplicatore;
                }
                if (comboBox1.Text == "1 euro")
                {
                    schei[6] = schei[6] + 1 * moltiplicatore;
                }
                if (comboBox1.Text == "2 euro")
                {
                    schei[7] = schei[7] + 2 * moltiplicatore;
                }
                if (comboBox1.Text == "5 euro")
                {
                    schei[8] = schei[8] + 5 * moltiplicatore;
                }
                if (comboBox1.Text == "10 euro")
                {
                    schei[9] = schei[9] + 10 * moltiplicatore;
                }
                if (comboBox1.Text == "20 euro")
                {
                    schei[10] = schei[10] + 20 * moltiplicatore;
                }
                if (comboBox1.Text == "50 euro")
                {
                    schei[11] = schei[11] + 50 * moltiplicatore;
                }
                if (comboBox1.Text == "100 euro")
                {
                    schei[12] = schei[12] + 100 * moltiplicatore;
                }
                label6.Text = SommaCassa(schei);
            }
            else
            {
                label6.Text = "Inserire numero di pezzi valido.Inserire taglio valido.";
            }
        }

        public bool VerificoCheSianoGiustiSoldi(ComboBox comboBox1, ComboBox comboBox2)
        {
            bool z = false;
            if ((comboBox1.Text == "1 centesimo" || comboBox1.Text == "2 centesimi" || comboBox1.Text == "5 centesimi " ||
                comboBox1.Text == "10 centesimi" || comboBox1.Text == "20 centesimi" || comboBox1.Text == "50 centesimi" ||
                comboBox1.Text == "1 euro" || comboBox1.Text == "2 euro" || comboBox1.Text == "5 euro" ||
                comboBox1.Text == "10 euro" || comboBox1.Text == "20 euro"
                || comboBox1.Text == "50 euro" || comboBox1.Text == "100 euro") && (comboBox2.Text == "x1" || comboBox2.Text == "x2" || comboBox2.Text == "x3" || comboBox2.Text == "x4" ||
                comboBox2.Text == "x5" || comboBox2.Text == "x6" || comboBox2.Text == "x7" || comboBox2.Text == "x8" ||
                comboBox2.Text == "x9" || comboBox2.Text == "x10" || comboBox2.Text == "x11" || comboBox2.Text == "x12" ||
                comboBox2.Text == "x13" || comboBox2.Text == "x14" || comboBox2.Text == "x15" || comboBox2.Text == "x16" ||
                comboBox2.Text == "x17" || comboBox2.Text == "x18" || comboBox2.Text == "x19" || comboBox2.Text == "x20"))
            {
                z = true;
            }
            else
            {
                z = false;
            }
            return z;
        }
        public void DammiMotiplicatore(ComboBox combobox)
        {
            string s = combobox.Text;
            moltiplicatore = Convert.ToInt32(s.Substring(1, (s.Length - 1)));
        }
        public string SommaCassa(int[] f)
        {
            string s = "";
            int decimali = 0;
            int interi = 0;
            for (int i = 0; i < f.Length; i++)
            {
                if (i < 6)
                {
                    decimali = decimali + f[i];
                    if (decimali > 0 && decimali / 100 >= 0)
                    {
                        for (int g = 0; decimali >= 100; g++)
                        {
                            decimali = decimali - 100;
                            interi = interi + 1;
                        }
                    }
                }
                else
                {
                    interi = interi + schei[i];
                }
            }
            return s = (Convert.ToString(interi) + ',' + Convert.ToString(decimali));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string totaleCarrello = label9.Text;
            int decimali = 0;
            int interi = 0;
            int punto = totaleCarrello.IndexOf(",");
            decimali = Convert.ToInt32(totaleCarrello.Substring(punto + 1));
            interi = Convert.ToInt32(totaleCarrello.Substring(0, punto));
            string prodotto = textBox1.Text;
            int puntoBox = prodotto.IndexOf(",");
            int decimaliBox = 1;
            int interiBox = 1;
            if (puntoBox == -1)
            {
                decimaliBox = 0;
                interiBox = Convert.ToInt32(prodotto);
            }
            else if (puntoBox == prodotto.Length)
            {
                prodotto.Remove(',');
            }
            else
            {
                decimaliBox = Convert.ToInt32(prodotto.Substring(puntoBox + 1));
                interiBox = Convert.ToInt32(prodotto.Substring(0, (puntoBox)));
            }

            interi = interi + interiBox;
            decimali = decimali + decimaliBox;
            if (decimali > 0 && decimali / 100 >= 0)
            {
                for (int g = 0; decimali >= 100; g++)
                {
                    decimali = decimali - 100;
                    interi = interi + 1;
                }
            }
            label9.Text = Convert.ToString(interi) + "," + Convert.ToString(decimali);
        }
       /* public void RestoDecimali(int[] f, int decimali)
        {
            bool noghìnsè = true;
            while (decimali != 0)
            {
                while (decimali <= 50 && de || noghìnsè == false)
                {
                    if (f[5] != 0)
                    {
                        decimali = decimali - 50;
                        f[5] = f[5] - 50;
                    }
                    else
                    {
                        noghìnsè = true;
                    }
                }
                while (decimali <= 20 || noghìnsè == false)
                {
                    if (f[4] != 0)
                    {
                        decimali = decimali - 20;
                        f[4] = f[4] - 20;
                    }
                    else
                    {
                        noghìnsè = true;
                    }
                }
                while (decimali <= 10 || noghìnsè == false)
                {
                    if (f[3] != 0)
                    {
                        decimali = decimali - 10;
                        f[3] = f[3] - 10;
                    }
                    else
                    {
                        noghìnsè = true;
                    }
                }
                while (decimali <= 5 || noghìnsè == false)
                {
                    if (f[2] != 0)
                    {
                        decimali = decimali - 5;
                        f[2] = f[2] - 5;
                    }
                    else
                    {
                        noghìnsè = true;
                    }
                }
                while (decimali <= 2 || noghìnsè == false)
                {
                    if (f[1] != 0)
                    {
                        decimali = decimali - 2;
                        f[1] = f[1] - 2;
                    }
                    else
                    {
                        noghìnsè = true;
                    }
                }
                while (decimali <= 1 || noghìnsè == false)
                {
                    if (f[0] != 0)
                    {
                        decimali = decimali - 1;
                        f[0] = f[0] - 1;
                    }
                    else
                    {
                        noghìnsè = true;
                    }
                }
            }
        }*/

        private void button3_Click(object sender, EventArgs e)
        {
            if (VerificoCheSianoGiustiSoldi(comboBox4, comboBox3) == true)
            {
                DammiMotiplicatore(comboBox3);

                if (comboBox4.Text == "1 centesimo")
                {
                    schei[0] = schei[0] + 1 * moltiplicatore;
                    scheiCliente[0] = scheiCliente[0] + 1 * moltiplicatore;
                }
                if (comboBox4.Text == "2 centesimi")
                {
                    schei[1] = schei[1] + 2 * moltiplicatore;
                    scheiCliente[1] = scheiCliente[1] + 2 * moltiplicatore;
                }
                if (comboBox4.Text == "5 centesimi")
                {
                    schei[2] = schei[2] + 5 * moltiplicatore;
                    scheiCliente[2] = scheiCliente[2] + 5 * moltiplicatore;
                }
                if (comboBox4.Text == "10 centesimi")
                {
                    schei[3] = schei[3] + 10 * moltiplicatore;
                    scheiCliente[3] = scheiCliente[3] + 10 * moltiplicatore;
                }
                if (comboBox4.Text == "20 centesimi")
                {
                    schei[4] = schei[4] + 20 * moltiplicatore;
                    scheiCliente[4] = scheiCliente[4] + 20 * moltiplicatore;
                }
                if (comboBox4.Text == "50 centesimi")
                {
                    schei[5] = schei[5] + 50 * moltiplicatore;
                    scheiCliente[5] = scheiCliente[5] + 50 * moltiplicatore;
                }
                if (comboBox4.Text == "1 euro")
                {
                    schei[6] = schei[6] + 1 * moltiplicatore;
                    scheiCliente[6] = scheiCliente[6] + 1 * moltiplicatore;
                }
                if (comboBox4.Text == "2 euro")
                {
                    schei[7] = schei[7] + 2 * moltiplicatore;
                    scheiCliente[7] = scheiCliente[7] + 2 * moltiplicatore;
                }
                if (comboBox4.Text == "5 euro")
                {
                    schei[8] = schei[8] + 5 * moltiplicatore;
                    scheiCliente[8] = scheiCliente[8] + 5 * moltiplicatore;
                }
                if (comboBox4.Text == "10 euro")
                {
                    schei[9] = schei[9] + 10 * moltiplicatore;
                    scheiCliente[9] = scheiCliente[9] + 10 * moltiplicatore;
                }
                if (comboBox4.Text == "20 euro")
                {
                    schei[10] = schei[10] + 20 * moltiplicatore;
                    scheiCliente[10] = scheiCliente[10] + 20 * moltiplicatore;
                }
                if (comboBox4.Text == "50 euro")
                {
                    schei[11] = schei[11] + 50 * moltiplicatore;
                    scheiCliente[11] = scheiCliente[11] + 50 * moltiplicatore;
                }
                if (comboBox4.Text == "100 euro")
                {
                    schei[12] = schei[12] + 100 * moltiplicatore;
                    scheiCliente[12] = scheiCliente[12] + 100 * moltiplicatore;
                }
                label13.Text = SommaCassa(scheiCliente);
                label6.Text = SommaCassa(schei);

            }
            else
            {
                label13.Text = "Inserire numero di pezzi valido.Inserire taglio valido.";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string soldiCliente = label13.Text;
             int puntoCliente = soldiCliente.IndexOf(",");
             int decimaliCliente = Convert.ToInt32(soldiCliente.Substring(puntoCliente + 1));
             int interiCliente = Convert.ToInt32(soldiCliente.Substring(0, puntoCliente));
             string soldiCarrello = label9.Text;
             int puntoCassa = soldiCliente.IndexOf(",");
             int decimaliCarrello = Convert.ToInt32(soldiCarrello.Substring(puntoCassa + 1));
             int interiCarrello = Convert.ToInt32(soldiCarrello.Substring(0, puntoCassa));
             /*if (interiCliente < interiCarrello || (interiCliente == interiCarrello && decimaliCliente < decimaliCarrello))
             {
                 label15.Text = "Credito non sufficiente... aggiungerne ancora prego";
             }
             else
             {
                 int interoProdotto = interiCliente - interiCarrello;
                 if (interiCliente > interiCarrello || (interiCliente == interiCarrello && decimaliCliente >= decimaliCarrello))
                 {
                     int decimaliProdotto = decimaliCliente - decimaliCarrello;                    
                 }
                 string s = SommaCassa(schei);
                 label15.Text = s;
             }*/
            double carrello = 0;
            double cliente = 0;
            string scarrello = Convert.ToString(interiCarrello) + "." + Convert.ToString(decimaliCarrello);
            carrello = Convert.ToDouble(scarrello);
            string scliente = Convert.ToString(interiCliente) + "." + Convert.ToString(decimaliCliente);
            cliente = Convert.ToDouble(scliente);
            if (cliente >= carrello)
            {
                int noghìnsè = 0;
                double restoCalcolami = cliente - carrello;
                while(restoCalcolami >= 0)
                {
                    if(restoCalcolami > 1 || restoCalcolami == 0)
                    {
                        for (int i = 12; i >= 6; i--)
                        {
                            int s = 0;
                            if(schei[i] != 0)
                            {if(i == 12)
                                {
                                     s = 100;
                                }
                                if (i == 11)
                                {
                                     s = 50;
                                }
                                if(i == 10)
                                {
                                     s = 20;
                                }
                                if (i == 9)
                                {
                                     s = 10;

                                }
                                if (i == 8)
                                {
                                     s = 5;
                                }
                                if (i == 7)
                                {
                                     s = 2;
                                }
                                if (i == 6)
                                {
                                     s = 1;
                                }
                                restoCalcolami = restoCalcolami - s;
                                schei[i] = schei[i] - s;
                                if (restoCalcolami > 0)
                                {
                                    label15.Text = Convert.ToString(restoCalcolami);
                                }
                            }
                        }
                    }
                    
                }
               
            }
            /*   while (restoCalcolami < 1)
              {
                   while (restoCalcolami <= 100)
                   {
                       if (schei[12] != 0)
                       {
                           restoCalcolami = restoCalcolami - 100;
                           schei[12] = schei[12] - 100;
                       }
                       else
                       {
                           noghìnsè++;
                           i++;
                           break;
                       }
                   }
                   while (restoCalcolami <= 50)
                   {
                       if (schei[11] != 0)
                       {
                           restoCalcolami = restoCalcolami - 50;
                           schei[11] = schei[11] - 50;
                       }
                       else
                       {
                           noghìnsè++;
                           break;
                       }
                   }
                   while (restoCalcolami <= 20)
                   {

                       if (schei[10] != 0)
                       {
                           restoCalcolami = restoCalcolami - 20;
                           schei[10] = schei[10] - 20;
                       }
                       else
                       {
                           noghìnsè++;
                           break;
                       }
                   }
                   while (restoCalcolami <= 10)
                   {
                       if (schei[9] != 0)
                       {
                           restoCalcolami = restoCalcolami - 10;
                           schei[9] = schei[9] - 10;
                       }
                       else
                       {
                           noghìnsè++;
                           break;
                       }
                   }
                   while (restoCalcolami <= 5)
                   {
                       if (schei[8] != 0)
                       {
                           restoCalcolami = restoCalcolami - 5;
                           schei[8] = schei[8] - 5;
                       }
                       else
                       {
                           noghìnsè++;
                           break;
                       }
                   }
                   while (restoCalcolami <= 2)
                   {
                       if (schei[7] != 0)
                       {
                           restoCalcolami = restoCalcolami - 2;
                           schei[7] = schei[7] - 2;
                       }
                       else
                       {
                           noghìnsè++;
                           break;
                       }
                   }
                   while (restoCalcolami <= 1)
                   {
                       if (schei[6] != 0)
                       {
                           restoCalcolami = restoCalcolami - 1;
                           schei[6] = schei[6] - 1;
                       }
                       else
                       {
                           noghìnsè++;
                           break;
                       }
               //    }
               }
               bool nonCeNeSono = false;
               while (restoCalcolami <= 0 && nonCeNeSono == false)
               {

                   while (restoCalcolami <= 50 && nonCeNeSono == false)
                   {
                       if (schei[5] != 0)
                       {
                           restoCalcolami = restoCalcolami - 50;
                           schei[5] = schei[5] - 50;
                       }
                       else
                       {
                           nonCeNeSono = true;
                       }
                   }
                   while (restoCalcolami <= 20 && nonCeNeSono == false)
                   {
                       if (schei[4] != 0)
                       {
                           restoCalcolami = restoCalcolami - 20;
                           schei[4] = schei[4] - 20;
                       }
                       else
                       {
                           nonCeNeSono = true;
                       }
                   }
                   while (restoCalcolami <= 10 && nonCeNeSono == false)
                   {
                       if (schei[3] != 0)
                       {
                           restoCalcolami = restoCalcolami - 10;
                           schei[3] = schei[3] - 10;
                       }
                       else
                       {
                           nonCeNeSono = true;
                       }
                   }
                   while (restoCalcolami <= 5 && nonCeNeSono == false)
                   {
                       if (schei[2] != 0)
                       {
                           restoCalcolami = restoCalcolami - 5;
                           schei[2] = schei[2] - 5;
                       }
                       else
                       {
                           nonCeNeSono = true;
                       }
                   }
                   while (restoCalcolami <= 2 && nonCeNeSono == false)
                   {
                       if (schei[1] != 0)
                       {
                           restoCalcolami = restoCalcolami - 2;
                           schei[1] = schei[1] - 2;
                       }
                       else
                       {
                           nonCeNeSono = true;
                       }
                   }
                   while (restoCalcolami <= 1 && nonCeNeSono == false)
                   {
                       if (schei[0] != 0)
                       {
                           restoCalcolami = restoCalcolami - 1;
                           schei[0] = schei[0] - 1;
                       }
                       else
                       {
                           nonCeNeSono = true;
                       }
                   }
                   label15.Text = Convert.ToString(restoCalcolami);
               }
           }*/
            else
            {
                label15.Text = "Importo insufficiente... aggiungine!";
            }
            label9.Text = "00,00";
            label13.Text = "0,0";
            label6.Text = "0,0";
            textBox1.Text = "";
        }
            }
        }
